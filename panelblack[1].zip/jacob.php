
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <title>Login Dashboard - ホストコード</title>
	<link rel="preconnect" href="https://fonts.googleapis.com"> <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin> <link href="https://fonts.googleapis.com/css2?family=Ramabhadra&family=Tilt+Neon&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.7/tailwind.min.css">
</head>
<body class="bg-gradient-to-br from-gray-800 bg-gray-900" style="font-family: 'Ramabhadra', sans-serif; font-family: 'Tilt Neon', sans-serif; padding-top:">
  <div id="login-modal" class="absolute top-0 left-0 w-full h-full flex justify-center items-center p-5">
    <div class="bg-gray-700 bg-opacity-50 rounded-lg p-12 border-2 border-gray-800 ">
    	<div class="flex justify-center">
  <a href="https://<?php echo $_SERVER['HTTP_HOST']; ?>">
    <img src="https://i.ibb.co/Chp50Rk/a29b813b2395ebe6b734489a308735c1.gif" class="w-30 h-30 rounded-full object-cover mb-4" alt="Logo" width="160" height="160">
    <meta name='description' itemprop='description' content='X-TOOLS VIP adalah sebuah website untuk membuat sebuah subdomain yang dapat digunakan untuk melakukan pointing ip server hosting anda ke subdomain kami.'>
    <meta property="og:title" content="X-TOOLS VIP">
    <meta property="og:description" content="X-TOOLS VIP adalah sebuah website untuk membuat sebuah subdomain yang dapat digunakan untuk melakukan pointing ip server hosting anda ke subdomain kami.">
    <meta property="og:url" content="index.php">
    <meta property="og:type" content="website">
    <meta property="og:image" content="dashboard/asset/thumbnail.jpg">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="627">
    <meta property="twitter:card" content="summary_large_image">
    <meta property="twitter:url" content="index.php">
    <meta property="twitter:title" content="X-TOOLS VIP">
    <meta property="twitter:description" content="X-TOOLS VIP adalah sebuah website untuk membuat sebuah subdomain yang dapat digunakan untuk melakukan pointing ip server hosting anda ke subdomain kami.">
    <meta property="twitter:image" content="dashboard/asset/thumbnail.jpg">
    <link rel="icon" href="dashboard/asset/favicon-32x32.png" type="image/png">
</head>
<body class="font-sans-serif p-2 bg-gray-900 text-sm" style="font-family: 'Ramabhadra', sans-serif; font-family: 'Tilt Neon', sans-serif; padding-top: 4rem;">
    <nav class="fixed z-50 top-0 left-0 right-0 flex flex-wrap border items-center justify-between bg-gray-800 p-2 mt-1 mx-auto rounded-lg" style="border-radius:20px;margin:5px;">
        <div class="flex items-center flex-shrink-0 text-white mr-6">
            <svg class="h-8 w-8 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z" />
                <path d="M12 14c-2.757 0-5-2.243-5-5s2.243-5 5-5 5 2.243 5 5-2.243 5-5 5zm0-8c-1.654 0-3 1.346-3 3s1.346 3 3 3 3-1.346 3-3-1.346-3-3-3z" />
            </svg>
            <a href="https://<?= $_SERVER['HTTP_HOST'] ?>" class="font-semibold font-bold text-2xl tracking-tight ml-4 bg-gradient-to-r from-blue-400 via-white to-green-500 text-transparent bg-clip-text hover:text-white hover:bg-clip-text">
                CRATE BLACK
            </a>
        </div>
        <div class="block lg:hidden">
            <button id="menu-toggle" class="flex items-center px-4 py-2 border rounded-lg text-gray-200 border-gray-400 hover:text-white hover:border-white">
                <i class="fas fa-bars"></i>
            </button>
        </div>
        <div id="nav-menu" class="hidden w-full lg:block lg:flex-grow lg:w-auto">
            <div class="text-center lg:flex-grow border-b border-gray-700 pb-2 text-xs"></div>
            <div class="lg:flex-grow border-b border-gray-700 pb-2" style="font-size: 12px;">
                <a href="#" class="hover:bg-transparent block w-full border-gray-100 border py-2 px-6 rounded-lg mt-4 lg:inline-block lg:mt-0 text-gray-200 hover:text-white hover:text-teal-500 mr-4 font-bold">
                    ⟩⟩ COMING SOON
                </a>
                <a href="#" class="hover-bg-transparent block w-full border-gray-100 border py-2 px-6 rounded-lg mt-1 mb-2 lg:inline-block lg:mt-0 text-gray-200 hover-text-white hover-text-teal-500 mr-4 font-bold">
                    ⟩⟩ COMING SOON
                </a>
            </div>
            <div class="flex justify-center text-center items-center mt-2 mb-2">
                <a href="login.php" class="inline-block px-8 py-2 leading-none rounded-full text-white bg-blue-500 hover-border-transparent hover-text-gray-100 hover-bg-blue-700 font-bold">SIGN-IN</a>
            </div>
        </div>
  </a>
</div>
      <h2 class="text-2xl font-bold mb-8 text-center text-white">- CRATE JASTEB -</h2>
      <?php if (isset($error)) { ?>
        <div class="bg-red-400 border justify-content-center text-center text-white font-bold rounded-lg mb-6">
          <?php echo $error; ?>
        </div>
      <?php } ?>
      <form action="proses2.php" method="post">
        <div class="mb-2">
          <input class="bg-gray-900 font-bold text-center border-2 border-gray-800 rounded-lg py-3 px-10 text-gray-300 leading-tight focus:outline-none focus:border-teal-500 w-full" id="text" type="text" name="text" placeholder="- username -">
        </div>
<div class="flex justify-center">
          <button class="bg-blue-500 hover:bg-teal-700 text-white font-bold py-1 px-6 rounded-lg focus:outline-none focus:shadow-outline border border-gray-100" type="submit" name="buatweb">
            CRATE
          </button>
           </div>
      </form>
    </div>
  </div>
</body>
<iframe scrolling='no' allow='autoplay' src='admin/sud.mp3' width='0' height='0' frameborder='no'></iframe>
</html>
         